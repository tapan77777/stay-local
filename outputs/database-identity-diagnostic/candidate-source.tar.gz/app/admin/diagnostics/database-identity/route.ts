import { isAdminAuthenticated } from "@/lib/plan/auth";
import { sql } from "@/lib/plan/db";
import { databaseIdentityDiagnostic, diagnosticHead } from "@/lib/plan/database-identity-diagnostic";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const maxDuration = 15;
export async function GET() {
  return databaseIdentityDiagnostic(isAdminAuthenticated, async () => {
    const client = sql();
    const [, rows] = await client.transaction([
      client.query("SELECT set_config('statement_timeout','5000',true),set_config('lock_timeout','1000',true)"),
      client.query("SELECT current_setting('neon.project_id',true) AS project_id,current_setting('neon.branch_id',true) AS branch_id,current_setting('transaction_read_only') AS read_only"),
    ], { readOnly: true, fetchOptions: { signal: AbortSignal.timeout(8000) } });
    return rows;
  });
}
export async function HEAD() {
  return diagnosticHead(isAdminAuthenticated);
}
